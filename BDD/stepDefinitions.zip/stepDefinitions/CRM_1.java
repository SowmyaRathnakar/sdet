package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;


public class CRM_1 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user logs in to CRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//form/div[2]/input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//form/div[3]/input[@id='username_password']")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//form/input[@id='bigbutton']")).click();
		Thread.sleep(5000);
	}
		
	@Then("^count the number of dashlets and print its title$")
		public void dashCount() throws Throwable {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h3/span[2]")));
		List<WebElement> count= driver.findElements(By.xpath("//h3/span[2]"));
		System.out.println("Number of dashlets on page is: "+ count.size());
		for (WebElement webElement: count) {
			String title = webElement.getText();
			System.out.println("The dashlet titles are:");
			System.out.println(title);
			
		}
	}
		
	@And("^close the browser once the counting is over$")
	public void closeBrowser() {
		driver.close();
	}

}
