package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CRM_3 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user has logged in to CRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//form/div[2]/input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//form/div[3]/input[@id='username_password']")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//form/input[@id='bigbutton']")).click();
		Thread.sleep(7000);
	}
		
	@When("^user navigates to schedule meeting$")
	public void navigate() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h3/span[2]")));
		driver.findElement(By.xpath("//ul[@class='nav navbar-nav']/li[5]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//ul/li[4]/a)[5]")));
		driver.findElement(By.xpath("(//ul/li[4]/a)[5]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div/ul/li[1]/a/div[2]")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/input[@id='name']")));
		driver.findElement(By.xpath("//div/input[@id='name']")).sendKeys("Urgent Meeting");
		Thread.sleep(2000);
	}
	
	@Then("^add meeting invitees through feature file with \"(.*)\"$")
		public void dashCount(String lastName) throws Throwable {
		driver.findElement(By.xpath("//tbody/tr/td/input[@id='search_last_name']")).sendKeys(lastName);
		driver.findElement(By.xpath("//tbody/tr/td/input[@id='invitees_search']")).click();
		Thread.sleep(2000);
	}
		
	@And ("^Save the meeting$")
	public void saveMeet() throws Throwable {
		driver.findElement(By.xpath("(//div/input[@id='SAVE_HEADER'])[2]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div/ul/li[2]/a/div[2]")).click();
		Thread.sleep(3000);
		String meet = driver.findElement(By.xpath("(//tbody/tr/td[4]/b/a)[1]")).getText();	
		Assert.assertEquals("Urgent Meeting", meet);
		System.out.println("Lead was successfully created");
		}
	
		
	@And("^user closes the browser after meeting schedule$")
	public void closeBrowser() {
		driver.close();
	}


}
