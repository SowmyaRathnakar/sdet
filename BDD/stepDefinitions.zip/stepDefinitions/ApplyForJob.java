package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class ApplyForJob {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^navigate to Jobs site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/jobs/");
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Jobs")));
		driver.findElement(By.linkText("Jobs")).click();
		Thread.sleep(5000);
	}
	
	@And("^keyword search to change job type$")
		public void locateUsers() throws Throwable {
		driver.findElement(By.id("search_keywords")).sendKeys("testing");
		Thread.sleep(1000);
	}
	
	@Then("^filter to only full time jobs$")
		public void addNewButton() throws Throwable {
		driver.findElement(By.className("freelance")).click();
		driver.findElement(By.className("internship")).click();
		driver.findElement(By.className("part-time")).click();
		driver.findElement(By.className("temporary")).click();
		driver.findElement(By.className("search_submit")).click();
		Thread.sleep(5000);
	}
	
	@And("^select job to check details and print job title$")
	public void fillingDetails() throws Throwable {
		driver.findElement(By.xpath("(//div/h3)[1]")).click();
		Thread.sleep(5000);
		String title = driver.findElement(By.className("entry-title")).getText();
		System.out.println("Title of the job is:" + title);
		
		
	}
	
	@Then("^apply for job$")
	public void verifyUser() throws Throwable {
		driver.findElement(By.xpath("//div/div[3]/input[@type='button']")).click();
	}
	
	@And("^close browser after applying for job$")
	public void closeBrowser() {
		driver.close();
	}
}
