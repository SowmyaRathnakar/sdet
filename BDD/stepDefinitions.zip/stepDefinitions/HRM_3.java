package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;



public class HRM_3 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user is logged into HRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div/input[@id='txtUsername']")).sendKeys("orange");
		driver.findElement(By.xpath("//div/input[@id='txtPassword']")).sendKeys("orangepassword123");
		driver.findElement(By.xpath("//div/input[@id='btnLogin']")).click();
		Thread.sleep(5000);
	}
	
	@Then("^add new employees for \"(.*)\" and \"(.*)\" and confirm employee is added successfully$")
	public void addEmployees(String FirstName, String LastName) throws Throwable {
		driver.findElement(By.id("menu_pim_viewPimModule")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form/div[1]/input[@id='btnAdd']")));
		driver.findElement(By.xpath("//form/div[1]/input[@id='btnAdd']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/fieldset/ol/li/ol/li[1]/input[@id='firstName']")).sendKeys(FirstName);
		driver.findElement(By.xpath("//form/fieldset/ol/li/ol/li[3]/input[@id='lastName']")).sendKeys(LastName);
		driver.findElement(By.xpath("//form/fieldset/ol/li[4]/input[@id='chkLogin']")).click();
		Thread.sleep(3000);
		String username = FirstName +" "+ LastName;
		driver.findElement(By.xpath("//form/fieldset/ol/li[5]/input[@id='user_name']")).sendKeys(username);
		driver.findElement(By.xpath("//form/fieldset/p/input[@id='btnSave']")).click();
		Thread.sleep(5000);
		String comp = driver.findElement(By.xpath("//div/div/div/div/h1")).getText();
		Assert.assertEquals(username, comp);
		System.out.println("Employee" + username+ " was successfully created");
	}
		
	@And("^close the browser once all employees are created$")
	public void closeBrowser() {
		driver.close();
	}
}
