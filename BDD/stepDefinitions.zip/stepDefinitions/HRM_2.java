package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class HRM_2 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user logs into HRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div/input[@id='txtUsername']")).sendKeys("orange");
		driver.findElement(By.xpath("//div/input[@id='txtPassword']")).sendKeys("orangepassword123");
		driver.findElement(By.xpath("//div/input[@id='btnLogin']")).click();
		Thread.sleep(5000);
	}
	
	@When("^user navigates to recruitment page and clicks add button$")
		public void locateUsers() throws Throwable {
		driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/div/input[@id='btnAdd']")).click();
		Thread.sleep(2000);
	}
	
		
	@Then("^fill in details of the candidate and upload resume$")
		public void addNewButton() throws Throwable {
		driver.findElement(By.xpath("//form/fieldset/ol/li[1]/ol/li[1]/input[@id='addCandidate_firstName']")).sendKeys("Sowmya");
		driver.findElement(By.xpath("//form/fieldset/ol/li[1]/ol/li[3]/input[@id='addCandidate_lastName']")).sendKeys("Rathnakar");
		driver.findElement(By.xpath("//form/fieldset/ol/li[2]/input[@id='addCandidate_email']")).sendKeys("sowmya.rathnakar@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/fieldset/ol[2]/li[2]/input[@id='addCandidate_resume']")).sendKeys("C:\\Users\\SowmyaRathnakar\\eclipse-workspace\\new workspace\\CucumberProjects\\src\\Resume.txt");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//form/fieldset/p/input[@id='btnSave']")).click();
		Thread.sleep(2000);
	}
	
	@And("^confirm candidate entry was successful$")
	public void fillingDetails() throws Throwable {
		driver.findElement(By.xpath("//form/fieldset/p/input[@id='btnBack']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/fieldset/ol/li[5]/input[@id='candidateSearch_candidateName']")).sendKeys("Sowmya Rathnakar");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/fieldset/p/input[@id='btnSrch']")).click();
		Thread.sleep(2000);
		String temp1 = driver.findElement(By.xpath("(//table/tbody/tr/td[3]/a)[1]")).getText();
		Assert.assertEquals(temp1, "Sowmya Rathnakar");
		System.out.println("Candidate entry is successful");
	}
	
	@Then("^close the browser once its successful$")
	public void closeBrowser() {
		driver.close();
	}

}
