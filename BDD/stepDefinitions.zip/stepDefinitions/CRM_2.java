package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;


public class CRM_2 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user logs into CRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//form/div[2]/input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//form/div[3]/input[@id='username_password']")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//form/input[@id='bigbutton']")).click();
		Thread.sleep(5000);
	}
		
	@Then("^navigate to create leads with lead name \"(.*)\"$")
		public void dashCount(String leadName) throws Throwable {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h3/span[2]")));
		driver.findElement(By.xpath("//div/div[2]/ul/li[2]/span[2]/a[@id='grouptab_0']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div/div[2]/ul/li[2]/span[2]/ul/li[5]")));
		driver.findElement(By.xpath("//div/div[2]/ul/li[2]/span[2]/ul/li[5]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div/ul/li[1]/a/div[2]")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@field='last_name']/input[@id='last_name']")));
		driver.findElement(By.xpath("//div[@field='last_name']/input[@id='last_name']")).sendKeys(leadName);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//div/input[@id='SAVE'])[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//ul/li[3]/a/div[2]")).click();
		Thread.sleep(3000);
		String lead = driver.findElement(By.xpath("(//tbody/tr/td[3]/b/a)[1]")).getText();	
		Assert.assertEquals(leadName, lead);
		System.out.println("Lead was successfully created");
		}
	
		
	@And("^user can close the browser$")
	public void closeBrowser() {
		driver.close();
	}

}
