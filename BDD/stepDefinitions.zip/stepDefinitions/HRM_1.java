package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class HRM_1 {
	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user logs in to HRM site$")
		public void adminLogIn() throws Throwable {
		driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div/input[@id='txtUsername']")).sendKeys("orange");
		driver.findElement(By.xpath("//div/input[@id='txtPassword']")).sendKeys("orangepassword123");
		driver.findElement(By.xpath("//div/input[@id='btnLogin']")).click();
		Thread.sleep(5000);
	}
	
	@When("^user navigates to recruitment page$")
		public void locateUsers() throws Throwable {
		driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
		Thread.sleep(2000);
	}
	
	@And("^then vacancies page to add job vacancy$")
	public void addVacancy() throws Throwable {
		driver.findElement(By.xpath("//div[2]/div/form/div[1]/input[@id='btnAdd']")).click();
		Thread.sleep(2000);
	}
	
	@Then("^fill in details and save vacancy$")
		public void addNewButton() throws Throwable {
		Select select = new Select (driver.findElement(By.id("addJobVacancy_jobTitle")));
		select.selectByVisibleText("Automation Test Engineer");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//ol/li[2]/input[@id='addJobVacancy_name']")).sendKeys("AutoTest");
		driver.findElement(By.xpath("//ol/li[3]/input[@id='addJobVacancy_hiringManager']")).sendKeys("Sowmya1 Billa1");
		driver.findElement(By.xpath("//form/fieldset/p/input[@id ='btnSave']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[2]/form/fieldset/p/input[@id='btnBack']")).click();
		Thread.sleep(2000);
	}
	
	@And("^confirm vacancy was created$")
	public void fillingDetails() throws Throwable {
		Select job = new Select (driver.findElement(By.id("vacancySearch_jobTitle")));
		job.selectByVisibleText("Automation Test Engineer");
		Thread.sleep(3000);
		Select vacancy = new Select (driver.findElement(By.id("vacancySearch_jobVacancy")));
		vacancy.selectByVisibleText("AutoTest");
		Thread.sleep(2000);
		Select manager = new Select (driver.findElement(By.id("vacancySearch_hiringManager")));
		manager.selectByVisibleText("Sowmya1 Billa1");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/fieldset/p/input[@id ='btnSrch']")).click();
		Boolean temp1 = driver.findElement(By.xpath("//table/tbody/tr/td[1]/input[@type='checkbox']")).isDisplayed();
		if (temp1=true)
			System.out.println("Job vacancy was created successfully"+ temp1);
		else
			System.out.println("Job vacancy not found");
	}
	
	@Then("^close the browser once done$")
	public void closeBrowser() {
		driver.close();
	}

}
