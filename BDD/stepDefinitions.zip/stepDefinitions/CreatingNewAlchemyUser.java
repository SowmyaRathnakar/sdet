package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreatingNewAlchemyUser {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^admin logs into Alchemy Job site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/jobs/wp-admin/");
		//wait = new WebDriverWait(driver, 15);
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@class=\"input\"]")));
		driver.findElement(By.xpath("//form/p/input[@class=\"input\"]")).sendKeys("root");
		driver.findElement(By.xpath("//form/div/div/input[@class=\"input password-input\"]")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//form/p/input[@id=\"wp-submit\"]")).click();
		Thread.sleep(5000);
	}
	
	@And("^locates Users option on left hand menu$")
		public void locateUsers() throws Throwable {
		driver.findElement(By.xpath("(//a/div[@class=\"wp-menu-name\"])[9]")).click();
		Thread.sleep(10000);
	}
	
	@When("^admin clicks on Add New button$")
		public void addNewButton() throws Throwable {
		driver.findElement(By.xpath("//a[@class=\"page-title-action\"]")).click();
		Thread.sleep(5000);
	}
	
	@Then("^fill in necessary details and click add new user$")
	public void fillingDetails() throws Throwable {
		driver.findElement(By.xpath("//input[@id=\"user_login\"]")).sendKeys("Sowmya1");
		driver.findElement(By.xpath("//input[@id=\"email\"]")).sendKeys("sowmyarathnakar@gmail.com");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//button[@class=\"button wp-generate-pw hide-if-no-js\"]")).click();
		driver.findElement(By.xpath("//input[@id=\"createusersub\"]")).click();
		Thread.sleep(10000);
	}
	
	@And("^verify new user is created$")
	public void verifyUser() throws Throwable {
		String veri = driver.findElement(By.xpath("(//div/p)[9]")).getText();
		Assert.assertEquals(veri,"New user created[*]");
		System.out.println("New user was created");
		Thread.sleep(5000);
	}
	
	@And("^close browser$")
	public void closeBrowser() {
		driver.close();
	}
}
