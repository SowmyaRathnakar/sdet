package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class PostAJob {
	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user navites to Jobs site$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/jobs/");
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Post a Job")));
		driver.findElement(By.linkText("Post a Job")).click();
		Thread.sleep(5000);
	}
	
	@When("^opts to post a job$")
		public void locateUsers() throws Throwable {
		driver.findElement(By.linkText("Sign in")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("user_login")).sendKeys("root");
		driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
		driver.findElement(By.id("wp-submit")).click();
		Thread.sleep(3000);
	}
	
	@Then("^fill in details from feaure file table for \"(.*)\" and \"(.*)\"$")
		public void enterPostDetails(String jobTitle, String description) throws Throwable {
		driver.findElement(By.id("job_title")).sendKeys(jobTitle);
		driver.findElement(By.id("job_description_ifr")).sendKeys(description);
		Thread.sleep(2000);
		driver.findElement(By.name("submit_job")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("job_preview_submit_button")).click();
		Thread.sleep(5000);
	}
	
	@And("^confirm job listing is shown$")
	public void fillingDetails() throws Throwable {
		driver.findElement(By.linkText("Jobs")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("search_keywords")).sendKeys("TestersFirst");
		String temp = driver.findElement(By.xpath("(//div/h3)[1]")).getText();
		Assert.assertEquals(temp, "TestersFirst");
		System.out.println("Posting a job is successful");
				
	}
}
