package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CRM_4 {

	WebDriver driver = new FirefoxDriver();
	WebDriverWait wait= new WebDriverWait(driver,20);
	
	@Given("^user is in CRM site and logged in$")
		public void adminLogIn() throws Throwable {
		driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//form/div[2]/input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//form/div[3]/input[@id='username_password']")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//form/input[@id='bigbutton']")).click();
		Thread.sleep(7000);
	}
		
	@Then("^create new product with name \"(.*)\" and price \"(.*)\"$")
	public void navigate(String PName, String PPrice) throws InterruptedException {
		driver.findElement(By.xpath("(//ul/li[7]/a)[1]")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//ul/li[25]/a)[2]")));
		driver.findElement(By.xpath("((//ul/li[25]/a)[2]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//a/div[2])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div/input[@id='name']")).sendKeys("PName");
		driver.findElement(By.xpath("//div/input[@id='price']")).sendKeys("PPrice");
		driver.findElement(By.xpath("//div/input[@id='SAVE']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//ul/li[2]/a/div[2]")).click();
		Thread.sleep(2000);
		String prod = driver.findElement(By.xpath("(/tbody/tr/td[3]/b/a)[1]")).getText();	
		Assert.assertEquals(PName, prod);
		System.out.println("Product was successfully created");
	}
			
		
	@And("^user can close browser after product creation$")
	public void closeBrowser() {
		driver.close();
	}


}
