package cucumberTest;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Features",
		glue= "stepDefinitions",
		tags= "@hrmActivity_4",
		publish = false,
		plugin = {"html:test-reports/HRM_4-testReports"},
	    monochrome = true
		)

public class HRM_4Runner {
}
