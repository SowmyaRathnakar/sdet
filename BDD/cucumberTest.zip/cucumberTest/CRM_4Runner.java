package cucumberTest;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Features",
		glue= "stepDefinitions",
		tags= "@crmActivity_4",
		publish = false,
		plugin = {"html:test-reports/CRM_4-testReports"},
	    monochrome = true
		)

public class CRM_4Runner {
}
