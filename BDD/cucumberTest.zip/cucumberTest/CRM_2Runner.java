package cucumberTest;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Features",
		glue= "stepDefinitions",
		tags= "@crmActivity_2",
		publish = false,
		plugin = {"html:test-reports/CRM_2-testReports"},
	    monochrome = true
		)

public class CRM_2Runner {
}
