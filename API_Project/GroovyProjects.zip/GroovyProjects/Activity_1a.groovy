package activities_groovy

class Activity_1a {
	static void main(def args) {
		def inputList= [11, 2, 19, 5, "Mango", "Apple", "Watermelon"]
		
		def intList = inputList.minus(["Mango", "Apple", "Watermelon"])
		println intList.sort()
		def strList = inputList.minus([11, 2, 19, 5])
		println strList.sort()
	}
}
